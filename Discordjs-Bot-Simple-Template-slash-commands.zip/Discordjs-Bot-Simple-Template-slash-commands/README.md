# Discord.js Bot Simple Template

This is a simple Discord.js bot template without too much clutter! Supports the newest Discord bot standard of **slash commands**. (Adapted from the official [discord.js guide](https://discordjs.guide/creating-your-bot/command-handling.html))

**[Click here for an in-depth template](https://replit.com/@FaustineW1/Discordjs-Bot-Guided-Template-slash-commands).**

>*No event handler included, as 'ready' and 'interactionCreate' events are sufficient for getting started.*

## File Structure

The relevant files of this template are organized as below:

```
files/
├── index.js
├── commands/
│   ├── ping.js
│   └── server.js
├── deploy-commands.js
└── README.md

```
Remember to add your own `TOKEN`, `CLIENT_ID`, and `GUILD_ID` entries to `Secrets`.

You can delete `README.md` when you fork the project!

### Good luck!

This was made as a submission to the Repl.it Template Jam. Compiling it has helped me learn so much about both javascript and Discord bots!

I'm not a professional programmer, so please keep improving on what I have. Looking forward to see what you create! :D

-- Faustine W.